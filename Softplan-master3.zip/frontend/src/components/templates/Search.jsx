import './Search.css'
import React from 'react'

export default props =>
    <div className="search"> <i className="fa fa-search"></i> Buscar </div>