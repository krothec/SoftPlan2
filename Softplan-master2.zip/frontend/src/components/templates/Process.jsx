import React from 'react'

export default props =>
    <header>
        <div className="process">Processos</div>
    </header>   