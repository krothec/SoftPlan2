import './Header.css'
import React from 'react'

export default props =>    
    <header className="header">
        <div className="column-app">APP</div> 
        <i className="column-icon fa fa-user-circle"></i>   
    </header>   

//as propriedades vem da tela Main, dentro da tag Header.