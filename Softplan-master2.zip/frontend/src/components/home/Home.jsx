import 'bootstrap/dist/css/bootstrap.min.css';
import { Card, CardImg, CardText, CardBody, CardTitle, CardSubtitle, Button } from 'reactstrap';
import React, { Component } from 'react'
import axios from 'axios'
import './Home.css'
import Nav from '../templates/Nav'
import PopOver from '../templates/PopOver'

const baseUrl = 'http://localhost:3001'
const initialState = {
    cards: [],
    tags: [],
    selectedTag: ''
}

export default class Home extends Component {

    state = { ...initialState }

    componentWillMount() {
        axios(`${baseUrl}/db`).then(resp => {
            this.setState({
                cards: resp.data.cards,
                tags: resp.data.tags
            })
        })
    }

    selectTag = (tag) => {
        this.setState({
            selectedTag: tag
        })
    }

    createTag = (name) => {
        this.setState({
            tags: [
                ...this.state.tags,
                {
                    id: this.state.tags.length + 1,
                    name,
                    color: "#FFF",
                    background: "#49bdce"
                }

            ]
        })
    }

    renderCards() {
        const filteredCards = this.state.cards.filter(card => {
            if (this.state.selectedTag === '') return true

            return card.tag.includes(parseInt(this.state.selectedTag))
        })

        return filteredCards.map(c => {
            return (
                <div className="pad">
                    <div className="row">
                        <div className="column left col-md-6">
                            <div className="row">                            
                                <i className="fa fa-plus-circle text-success name"></i> {c.partes.ativa.name}                            
                                <i className="fa fa-minus-circle text-danger name2"></i> {c.partes.passiva.name}                                                       
                            </div>
                            <div className="row subject">     
                                {c.classe} - <b className="subject"> {c.assunto}</b>
                            </div>
                            <div className="row"> 
                                {c.numero} 
                            </div>                           
                        </div>
                        <div className="column middle col-md-3">
                            <p className="icon-folder"><i className="fa fa-folder-open"></i> Abrir pasta</p>

                        </div>
                        <div className="column right col-md-3">
                            <PopOver tags={this.state.tags} />                             
                        </div>
                        </div>
                </div>
            )
        })
    }

    render() {
        return (
            <React.Fragment>
                <Nav
                    tags={this.state.tags}
                    cards={this.state.cards}
                    selectedTag={this.state.selectedTag}
                    onSelectTag={this.selectTag}
                    onCreateTag={this.createTag}
                />
                <main className="content">
                    <div className="search"> <i className="fa fa-search"></i> Buscar </div>
                    <div className="container-fluid">
                        {this.renderCards()}
                    </div>
                </main>
            </React.Fragment>
        )
    }
}